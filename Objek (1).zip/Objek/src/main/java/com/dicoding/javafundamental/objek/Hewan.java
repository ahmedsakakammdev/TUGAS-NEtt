/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.dicoding.javafundamental.objek;

/**
 *
 * @author admin
 */
public class Hewan {
    public void cetakNama(String nama) {
       System.out.println("Nama hewan: " + nama);
}
}
